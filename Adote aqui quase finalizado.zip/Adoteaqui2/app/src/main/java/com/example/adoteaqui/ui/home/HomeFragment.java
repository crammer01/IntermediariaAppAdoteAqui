package com.example.adoteaqui.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.example.adoteaqui.R;

import java.util.zip.Inflater;

public class HomeFragment extends Fragment implements View.OnClickListener {

    private HomeViewModel homeViewModel;

    private Button btn_info1;
    private Button btn_info2;
    private Button btn_info3;
    private Button btn_info4;
    private Button btn_info5;
    private Button btn_info6;

    private View mVIew;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        mVIew = inflater.inflate(R.layout.fragment_home, container, false);
        btn_info1 = mVIew.findViewById(R.id.btn_infoH1_id);

        /*btn_info1 = getActivity().findViewById(R.id.btn_infoH1_id);
        btn_info2 = getActivity().findViewById(R.id.btn_infoH2_id);
        btn_info3 = getActivity().findViewById(R.id.btn_infoH3_id);
        btn_info4 = getActivity().findViewById(R.id.btn_infoH4_id);
        btn_info5 = getActivity().findViewById(R.id.btn_infoH5_id);
        btn_info6 = getActivity().findViewById(R.id.btn_infoH6_id);

            btn_info1.setOnClickListener(this);
            btn_info2.setOnClickListener(this);
            btn_info3.setOnClickListener(this);
            btn_info4.setOnClickListener(this);
            btn_info5.setOnClickListener(this);
            btn_info6.setOnClickListener(this);
        */

        btn_info1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Toast toast;
               toast = Toast.makeText(getActivity(), "Seu contato foi enviado ao doador, aguarde o contato!", Toast.LENGTH_LONG);
               toast.show();
            }
        });

        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        return root;
    }

    @Override
    public void onClick(View v) {
        Toast.makeText(getActivity(), "Seu contato foi enviado ao doador, aguarde o contato!", Toast.LENGTH_LONG).show();
    }
}